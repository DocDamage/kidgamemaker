<script lang="ts">
  import { invoke } from "@tauri-apps/api/core";
  import ToyboxModal from "./ToyboxModal.svelte";
  import {
    eraseEntity,
    snapPosition,
    stampEntity,
    toRoomPayload,
    type PlacedEntity,
    type ToyboxAsset
  } from "./lib/canvasState";

  let placed: PlacedEntity[] = [
    {
      instance_id: "hero_001",
      asset_id: "hero_knight",
      category: "heroes",
      type: "player",
      position: { x: 120, y: 220 },
      is_camera_target: true,
      modifiers: { variant: "default", scale_multiplier: 1.0 }
    },
    {
      instance_id: "floor_001",
      asset_id: "stone_floor",
      category: "terrain",
      type: "terrain",
      position: { x: 320, y: 360 },
      modifiers: { variant: "default", scale_multiplier: 1.0 }
    }
  ];

  let activeAsset: ToyboxAsset = {
    id: "stone_floor",
    name: "Stone Floor",
    category: "terrain",
    visual: "🪨",
    type: "terrain"
  };

  let eraserMode = false;
  let toyboxOpen = false;
  let status = "Ready";

  const quickRibbon: ToyboxAsset[] = [
    { id: "hero_knight", name: "Hero", category: "heroes", visual: "🛡️", type: "player" },
    { id: "stone_floor", name: "Floor", category: "terrain", visual: "🪨", type: "terrain" }
  ];

  function handleCanvasClick(event: MouseEvent) {
    const target = event.currentTarget as HTMLDivElement;
    const rect = target.getBoundingClientRect();
    const position = snapPosition({
      x: event.clientX - rect.left,
      y: event.clientY - rect.top
    });

    if (eraserMode) {
      const hit = [...placed].reverse().find((item) => {
        const dx = item.position.x - position.x;
        const dy = item.position.y - position.y;
        return Math.sqrt(dx * dx + dy * dy) < 32;
      });

      if (hit) {
        placed = eraseEntity(placed, hit.instance_id);
      }

      return;
    }

    placed = stampEntity(placed, activeAsset, position);
  }

  async function play() {
    status = "Writing game_state.json...";
    try {
      const payload = toRoomPayload(placed);
      status = await invoke<string>("compile_and_play", { roomPayload: payload });
    } catch (error) {
      status = `Play failed: ${error}`;
    }
  }

  function selectAsset(asset: ToyboxAsset) {
    activeAsset = asset;
    eraserMode = false;
    toyboxOpen = false;
  }
</script>

<main class="app-shell">
  <header class="topbar">
    <button class="play" on:click={play}>▶ PLAY</button>
    <button class:active={!eraserMode} on:click={() => (eraserMode = false)}>
      Stamp: {activeAsset.visual ?? "🎮"}
    </button>
    <button class:active={eraserMode} on:click={() => (eraserMode = !eraserMode)}>
      🧽 Eraser
    </button>
    <button on:click={() => (toyboxOpen = true)}>🧰 Toybox</button>
  </header>

  <section class="quick-ribbon">
    {#each quickRibbon as asset}
      <button
        class:active={activeAsset.id === asset.id && !eraserMode}
        on:click={() => selectAsset(asset)}
        title={asset.name}
      >
        <span>{asset.visual}</span>
        <small>{asset.name}</small>
      </button>
    {/each}
  </section>

  <section class="canvas" on:click={handleCanvasClick}>
    {#each placed as item (item.instance_id)}
      <button
        class="stamp {item.category}"
        style:left={`${item.position.x}px`}
        style:top={`${item.position.y}px`}
        title={`${item.asset_id} ${item.instance_id}`}
        on:click|stopPropagation={() => {
          if (eraserMode) placed = eraseEntity(placed, item.instance_id);
        }}
      >
        {item.asset_id === "hero_knight" ? "🛡️" : item.asset_id === "stone_floor" ? "🪨" : "🎮"}
      </button>
    {/each}
  </section>

  <footer>
    <code>{status}</code>
  </footer>

  <ToyboxModal isVisible={toyboxOpen} on:itemSelected={(event) => selectAsset(event.detail)} on:close={() => (toyboxOpen = false)} />
</main>

<style>
  :global(body) {
    margin: 0;
    font-family: system-ui, sans-serif;
    background: #18202f;
    color: white;
    overflow: hidden;
  }

  .app-shell {
    height: 100vh;
    display: grid;
    grid-template-rows: auto auto 1fr auto;
  }

  .topbar,
  .quick-ribbon,
  footer {
    display: flex;
    gap: 12px;
    align-items: center;
    padding: 12px;
    background: #101827;
    border-bottom: 3px solid rgba(255, 255, 255, 0.08);
  }

  button {
    border: 0;
    border-radius: 18px;
    padding: 12px 18px;
    font-weight: 800;
    cursor: pointer;
    background: #f3f5ff;
    color: #101827;
    box-shadow: 0 5px 0 rgba(0, 0, 0, 0.35);
  }

  button:active {
    transform: translateY(3px);
    box-shadow: 0 2px 0 rgba(0, 0, 0, 0.35);
  }

  button.active {
    outline: 4px solid #ffd84d;
  }

  .play {
    background: #55e36f;
    font-size: 1.2rem;
  }

  .quick-ribbon button {
    display: grid;
    place-items: center;
    min-width: 92px;
  }

  .quick-ribbon span {
    font-size: 2rem;
  }

  .canvas {
    position: relative;
    overflow: hidden;
    background:
      linear-gradient(rgba(255,255,255,.06) 1px, transparent 1px),
      linear-gradient(90deg, rgba(255,255,255,.06) 1px, transparent 1px),
      #27364f;
    background-size: 32px 32px;
  }

  .stamp {
    position: absolute;
    transform: translate(-50%, -50%);
    width: 52px;
    height: 52px;
    padding: 0;
    display: grid;
    place-items: center;
    font-size: 2rem;
    border-radius: 50%;
  }

  .stamp.terrain {
    width: 160px;
    border-radius: 14px;
  }

  footer {
    border-top: 3px solid rgba(255, 255, 255, 0.08);
    border-bottom: 0;
  }
</style>

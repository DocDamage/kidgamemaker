mod commands;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .invoke_handler(tauri::generate_handler![
            commands::compile_and_play,
            commands::get_asset_inventory
        ])
        .run(tauri::generate_context!())
        .expect("error while running KidGameMaker Tauri application");
}

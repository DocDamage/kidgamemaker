# GitHub Setup

Target repo:

```text
https://github.com/DocDamage/kidgamemaker
```

## Apply this starter pack manually

From a terminal:

```bash
git clone https://github.com/DocDamage/kidgamemaker.git
cd kidgamemaker
```

Create the baseline folders:

```bash
mkdir -p docs/schemas engine/scripts engine/data/assets editor/src/lib editor/src-tauri/src .github/workflows
```

Copy this starter pack's contents into the repo root.

Then commit:

```bash
git add .
git commit -m "Add KidGameMaker architecture and starter runtime contracts"
git push -u origin main
```

## Scaffold Tauri/Svelte

Inside the repo:

```bash
npm create tauri-app@latest editor
```

Recommended choices:
- frontend: Svelte
- language: TypeScript
- backend: Rust

After scaffolding, merge the starter files from:

```text
editor/src/
editor/src-tauri/src/
```

Do not overwrite generated config files blindly. Keep the generated Tauri config, then add the commands from this starter pack.

## Create the Godot project

Open Godot 4 and create/import a project in:

```text
kidgamemaker/engine
```

Add:
- `scripts/Main.gd`
- `scripts/PlayerController.gd`
- `scripts/SmartEnemy.gd`
- `data/dummy_level.json`
- `data/assets/...`

Create a `Node2D` scene named `Main.tscn`, attach `Main.gd`, and set it as the main scene.

## First commit targets

The first useful repo commit should contain:
- docs
- JSON schemas
- dummy level data
- Godot scripts
- Tauri command skeleton
- simple Svelte canvas prototype

The first commit does **not** need:
- finished installer
- real asset slicing
- AI tagging
- production art
- exported Godot runner

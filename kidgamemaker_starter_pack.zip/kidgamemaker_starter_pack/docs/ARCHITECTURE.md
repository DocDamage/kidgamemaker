# Architecture

## Product goal

KidGameMaker is a native desktop side-scrolling game maker for a young child. The child never sees code, file structures, sprite slicing tools, import settings, node graphs, or build systems. They place visual stamps, press Play, and the engine handles the rest.

The system still needs enough depth to eventually support games with:
- platforming
- Metroidvania gates
- rooms/worlds
- multiple heroes
- enemies
- collectibles
- checkpoints
- lighting
- parallax
- weather
- day/night
- NPC routines
- background music
- spatial sound effects
- project saving/exporting

## System overview

```text
┌─────────────────────────────────────────────────────────────┐
│ Editor: Svelte UI inside Tauri                              │
│ - Mario Maker-style stamp ribbon                            │
│ - Toybox modal                                               │
│ - Freeform canvas with magnetic snapping                     │
│ - Bookshelf project picker                                   │
│ - Big Play button                                            │
└───────────────────────────┬─────────────────────────────────┘
                            │ Tauri invoke()
                            ▼
┌─────────────────────────────────────────────────────────────┐
│ Rust backend                                                 │
│ - Receives canvas state                                      │
│ - Writes game_state.json                                     │
│ - Scans asset sidecars                                       │
│ - Watches _Inbox                                             │
│ - Unzips asset packs                                         │
│ - Slices sprite sheets                                       │
│ - Generates metadata                                         │
│ - Launches Godot runner                                      │
└───────────────────────────┬─────────────────────────────────┘
                            │ JSON contract
                            ▼
┌─────────────────────────────────────────────────────────────┐
│ Godot runner                                                 │
│ - Reads game_state.json                                      │
│ - Reads sidecar JSON                                         │
│ - Spawns nodes                                               │
│ - Applies physics                                            │
│ - Applies camera/parallax                                    │
│ - Applies lighting/audio/weather/checkpoints/gates           │
└─────────────────────────────────────────────────────────────┘
```

## Repo structure

```text
/kidgamemaker
├── editor/
│   ├── src/
│   │   ├── App.svelte
│   │   ├── ToyboxModal.svelte
│   │   └── lib/
│   │       └── canvasState.ts
│   └── src-tauri/
│       └── src/
│           ├── lib.rs
│           └── commands.rs
├── engine/
│   ├── project.godot
│   ├── scenes/
│   ├── scripts/
│   │   ├── Main.gd
│   │   ├── PlayerController.gd
│   │   └── SmartEnemy.gd
│   └── data/
│       ├── dummy_level.json
│       └── assets/
│           ├── heroes/
│           ├── terrain/
│           ├── enemies/
│           ├── collectibles/
│           ├── backgrounds/
│           ├── portals/
│           ├── decorations/
│           └── audio/
├── docs/
└── .github/workflows/
```

## Core data flow

1. User stamps assets in the Svelte canvas.
2. Svelte stores a flat array of placed entities.
3. User presses Play.
4. Svelte calls Rust through `invoke("compile_and_play")`.
5. Rust writes the payload to `engine/data/game_state.json`.
6. Rust launches Godot and passes the JSON file path.
7. Godot reads the JSON, loads matching asset sidecars, and spawns gameplay objects.

## Why Godot runner instead of custom runtime

Use Godot for the runner because the project needs strong 2D support quickly:
- `FileAccess` reads/writes runtime data files.
- `JSON` parses the game-state contract.
- `CharacterBody2D` is built for controlled 2D player/enemy motion.
- `Camera2D` handles side-scrolling camera movement.
- Static/dynamic/area physics nodes are already mature.
- 2D lights, particles, audio, and animation tools are built in.

The Rust backend should handle ingestion and orchestration, not reinvent the game engine.

## Why Tauri/Svelte

Tauri gives native file-system access and a Rust backend while keeping the child UI built with web technology. Svelte is a good fit for the bouncy, low-friction, animated interface because it compiles to small direct DOM updates and keeps state simple.

## Rule of thumb

The editor records **what the child placed**.

The Rust backend decides **what files and metadata exist**.

The Godot runner decides **how it plays**.

# Godot Runner Starter

This folder is for the Godot template runner.

## Setup

1. Open Godot 4.
2. Create a project in this `engine/` folder.
3. Create a root scene with a `Node2D` named `Main`.
4. Attach `scripts/Main.gd` to `Main`.
5. Set that scene as the main scene.
6. Run the project.

The runner reads:

```text
engine/data/dummy_level.json
```

Later, Tauri/Rust will write:

```text
engine/data/game_state.json
```

and launch Godot with:

```bash
--level-json /absolute/path/to/game_state.json
```

## What works in this starter

- JSON room loading.
- Sidecar lookup by asset id.
- Placeholder terrain/player/enemy/decoration spawning.
- Gravity player controller.
- Camera attachment through `is_camera_target`.
- Z-index assignment from parallax bucket.

## What is intentionally not done yet

- Real sprite loading.
- Real animation player setup.
- Real parallax background nodes.
- Real lighting textures.
- Real audio manager.
- Save system.
- Room streaming.

from pathlib import Path
import json
import sys

ROOT = Path(__file__).resolve().parents[1]
errors: list[str] = []

for path in sorted(ROOT.rglob('*.json')):
    if any(part in {'node_modules', 'target', '.svelte-kit', 'dist'} for part in path.parts):
        continue
    try:
        json.loads(path.read_text(encoding='utf-8'))
    except Exception as exc:  # noqa: BLE001
        errors.append(f'{path.relative_to(ROOT)}: {exc}')

if errors:
    print('JSON validation failed:')
    for error in errors:
        print(f' - {error}')
    sys.exit(1)

print('All JSON files parsed successfully.')

# Implementation Roadmap for a One-Person Team

## Principle

Do not build the whole dream first. Build a thin playable vertical slice, then expand one system at a time.

The first playable version should look boring internally but prove the architecture.

## Phase 0 — Repo and toolchain

Goal: Make the repo usable.

Tasks:
- Clone `https://github.com/DocDamage/kidgamemaker.git`.
- Create `editor/`, `engine/`, `docs/`, and `.github/workflows/`.
- Scaffold Tauri + Svelte in `editor/`.
- Create a Godot 4 project in `engine/`.
- Add this starter documentation.
- Commit the baseline.

Done when:
- Repo has the monorepo folders.
- `npm install` works in `editor/`.
- Godot opens `engine/project.godot`.

## Phase 1 — Godot JSON runner

Goal: Prove `dummy_level.json` can become a playable room.

Tasks:
- Attach `scripts/Main.gd` to a `Node2D` named `Main`.
- Add `scripts/PlayerController.gd`.
- Add `data/dummy_level.json`.
- Add hand-authored sidecars for `hero_knight` and `stone_floor`.
- Spawn placeholders if sprites do not exist yet.

Done when:
- Player spawns.
- Floor spawns.
- Player falls and lands.
- Camera follows player.
- Console shows which JSON file loaded.

## Phase 2 — Tauri bridge

Goal: Prove the editor can launch the runner.

Tasks:
- Add Rust command `compile_and_play`.
- Add Rust command `get_asset_inventory`.
- Add a Svelte Play button.
- Send dummy room payload from Svelte to Rust.
- Rust writes `engine/data/game_state.json`.
- Rust launches Godot with `--level-json`.

Done when:
- Clicking Play writes JSON.
- Godot starts with the generated room payload.
- If Godot runner is missing, Rust returns a clean message instead of crashing.

## Phase 3 — Child-facing canvas MVP

Goal: Basic Mario Maker-style stamping.

Tasks:
- Implement quick ribbon with 5–7 active stamps.
- Implement Toybox modal.
- Use a flat `PlacedEntity[]` array.
- Click canvas to stamp.
- Eraser removes by `instance_id`.
- Press Play to run current canvas.

Done when:
- A non-technical user can place hero/floor/enemy/collectible/background.
- The payload produced by the UI matches `room_state.schema.json`.

## Phase 4 — Sidecar-driven toybox

Goal: Rust populates the editor from asset folders.

Tasks:
- Scan `engine/data/assets/<category>/<asset_id>/<asset_id>.json`.
- Return inventory grouped by category.
- Display assets in Toybox.
- Slot selected asset into quick ribbon.

Done when:
- Adding a new hand-authored sidecar makes it appear in the Toybox without code changes.

## Phase 5 — Deterministic asset ingestion

Goal: First real backend value.

Tasks:
- Create `_Inbox`.
- Watch for dropped files.
- Unzip archives.
- Copy supported files into staging.
- Detect image/audio/doc types.
- For PNG sprites, run alpha-threshold connected-component slicing.
- Generate initial sidecar JSON.
- Route to category folders.

Done when:
- Dropping a simple transparent PNG sheet produces sliced frames and a sidecar.
- Dropping an audio file creates an audio sidecar.
- The Toybox refreshes.

## Phase 6 — Smart placement

Goal: Hide complexity without lying to the user.

Tasks:
- Edge snapping for terrain.
- Gravity snapping for players/enemies/checkpoints.
- Surface/socket snapping for torches/signs/decorations.
- Parallax bucket assignment.
- Z-index assignment.

Done when:
- Child can place assets freely and they still land cleanly.

## Phase 7 — Basic gameplay rules

Goal: Make levels feel like games.

Tasks:
- Collectibles.
- Damage.
- Respawn at hero start.
- Checkpoint override.
- Door/portal room linking.
- Key-door matching by tags.
- Enemy patrol.
- Basic boss candidate behavior for huge enemies.

Done when:
- A small two-room game can be built and completed.

## Phase 8 — Atmosphere

Goal: Make rooms feel premium.

Tasks:
- CanvasModulate day/night.
- PointLight2D attachment for light-emitting sidecars.
- Weather particles from room/theme tags.
- Jukebox/music block zones.
- Spatial SFX anchors.
- Dynamic boss music override.

Done when:
- A torch lights a dark room.
- A placed music block changes the track.
- A boss overrides the current music.

## Phase 9 — Projects and export

Goal: Make it usable as a real product.

Tasks:
- Visual Bookshelf.
- Auto-thumbnail saves.
- New world button with generated names.
- Auto-save.
- Project folder copy/export.
- Publish zip with runner + used assets + JSON.

Done when:
- Child can maintain more than one game.
- A playable game zip can be created.

## Do not start with

- AI vision classification
- Full NPC routines
- Full Metroidvania progression analyzer
- Procedural world generation
- Published installers
- Full sprite rigging/animation editor

Those are later systems. Starting there will bury the MVP.

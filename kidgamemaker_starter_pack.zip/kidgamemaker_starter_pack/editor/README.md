# Editor Starter

This is not a full generated Tauri project. Scaffold Tauri/Svelte first, then merge these files.

Recommended:

```bash
npm create tauri-app@latest editor
```

Choices:
- Svelte
- TypeScript
- Rust

Then add/merge:
- `src/App.svelte`
- `src/ToyboxModal.svelte`
- `src/lib/canvasState.ts`
- `src-tauri/src/commands.rs`
- `src-tauri/src/lib.rs`

If your Tauri template already generated `lib.rs`, merge the command registration instead of blindly replacing it.

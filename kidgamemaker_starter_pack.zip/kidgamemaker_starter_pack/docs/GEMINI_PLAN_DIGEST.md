# Gemini Plan Digest

## What Gemini got right

The useful core of the conversation is the **data-driven runtime** idea. The app should not compile a new game binary every time the child hits Play. The editor should write a room/world JSON file, then launch a pre-built Godot runner that reads that JSON and spawns the game.

The right stack is:

```text
Svelte UI → Tauri IPC → Rust backend → JSON files → Godot runner
```

The right repo layout is:

```text
/kidgamemaker
├── editor/     # Svelte + Tauri child-facing editor
├── engine/     # Godot runner
├── docs/       # architecture and JSON contracts
└── .github/    # CI
```

The right asset design is **sidecar JSON per asset**, not one massive global database.

The right UX is **Mario Maker-style stamping**, not a normal game engine editor.

## What needs correction

Gemini kept implying AI can reliably infer complex game design intent from placement alone. That is only partly true.

The engine can safely automate:
- key opens matching colored door
- big enemy becomes boss candidate
- player/enemy gravity snapping
- terrain edge snapping
- torch emits light
- placed jukebox controls area music
- checkpoint overrides respawn point
- background asset goes to parallax layer

The engine should **not** rely on AI as the first-pass source of truth for:
- automatic animation naming
- boss arena design
- full Metroidvania progression validation
- NPC daily routines
- room-to-room pacing
- puzzle solvability

Those need deterministic rules first, AI hints second.

## Correct build order

1. **Godot runner proof**
   - Load `dummy_level.json`.
   - Spawn player and terrain.
   - Attach camera.
   - Apply gravity and movement.

2. **Tauri bridge**
   - Svelte button sends a dummy room payload.
   - Rust writes `engine/data/game_state.json`.
   - Rust launches Godot with `--level-json`.

3. **Svelte canvas**
   - Flat `currentRoomState` array.
   - Stamp entities onto canvas.
   - Eraser deletes by `instance_id`.
   - Toybox reads asset inventory from Rust.

4. **Asset sidecars**
   - Use hand-authored sidecars first.
   - Then build the Rust ingestor to generate them.

5. **Asset ingestion**
   - Watch `_Inbox`.
   - Unzip packs.
   - Parse images/audio/docs.
   - Generate sidecar JSON.
   - Route assets into category folders.

6. **Automation systems**
   - Snap rules.
   - Parallax buckets.
   - Audio triggers.
   - Lighting metadata.
   - Checkpoints.
   - Doors/keys.
   - Boss candidates.
   - Weather inference.

7. **Advanced child UX**
   - Bookshelf project manager.
   - Auto-thumbnails.
   - Drop-in ghost testing.
   - Publish/export zip.

## MVP definition

The MVP is successful when:

- The child can pick a hero, floor, enemy, coin, door, and background.
- The child can stamp them freely on a canvas.
- The child can press Play.
- Godot opens a playable room from JSON.
- The player can move, jump, collide with ground, and follow the camera.
- Assets are loaded from sidecar JSON.
- No code is visible to the child.

Anything beyond that is Phase 2+.

# Codex / IDE Prompt to Apply Starter Pack

Use this repo:

```text
https://github.com/DocDamage/kidgamemaker
```

Apply the KidGameMaker starter architecture as a monorepo.

## Goal

Create a native desktop side-scrolling game maker for young children. The editor must hide code, file handling, sprite slicing, and engine internals. The child should stamp assets onto a Mario Maker-style canvas and press Play. The runtime should be data-driven through JSON.

## Required repo structure

```text
/kidgamemaker
├── editor/
│   ├── src/
│   └── src-tauri/
├── engine/
│   ├── scripts/
│   └── data/
├── docs/
│   └── schemas/
└── .github/workflows/
```

## Implement first

1. Add docs from starter pack.
2. Add JSON schemas.
3. Add Godot scripts:
   - `engine/scripts/Main.gd`
   - `engine/scripts/PlayerController.gd`
   - `engine/scripts/SmartEnemy.gd`
4. Add dummy data:
   - `engine/data/dummy_level.json`
   - `engine/data/assets/heroes/hero_knight/hero_knight.json`
   - `engine/data/assets/terrain/stone_floor/stone_floor.json`
5. Add Tauri Rust commands:
   - `compile_and_play`
   - `get_asset_inventory`
6. Add starter Svelte UI:
   - `App.svelte`
   - `ToyboxModal.svelte`
   - `lib/canvasState.ts`

## Rules

- Do not build the full AI ingestion system yet.
- Do not add placeholder features that pretend to be complete.
- The first milestone is a playable Godot room from JSON.
- Keep data contracts stable and documented.
- Prefer small, verified vertical slices.
- Preserve the monorepo boundaries.

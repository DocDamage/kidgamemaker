# KidGameMaker Starter Pack

This pack turns the Gemini conversation into a concrete starting point for `DocDamage/kidgamemaker`.

The cleaned-up direction is:

- **Native desktop app**, not a web-only app.
- **One monorepo** containing editor, engine, docs, and CI.
- **Svelte + Tauri editor** for the Mario Maker-style child-facing UI.
- **Rust backend** for file watching, asset ingestion, sidecar JSON generation, project saving, and launching the runner.
- **Godot template runner** for the actual playable game runtime.
- **Data-driven JSON contracts** so the editor, Rust backend, and Godot runner all speak the same language.
- **Start contract-first**: prove `game_state.json` can spawn a playable Godot room before building the full asset AI pipeline.

## Why this is the right interpretation

The Gemini thread is useful, but it rambles. The real architecture underneath it is simple:

```text
Child UI stamps objects
        ↓
Svelte keeps flat canvas state
        ↓
Tauri sends state to Rust
        ↓
Rust writes game_state.json
        ↓
Godot runner reads JSON and spawns gameplay
        ↓
Asset sidecar JSON gives each object behavior, snapping, audio, lighting, animation, and physics rules
```

That is the buildable core. Everything else — AI classification, auto-slicing, smart boss logic, Metroidvania gates, weather, NPC routines — should be layered onto that core after the JSON contract works.

## What is inside

```text
kidgamemaker_starter_pack/
├── README.md
├── docs/
│   ├── GEMINI_PLAN_DIGEST.md
│   ├── ARCHITECTURE.md
│   ├── IMPLEMENTATION_ROADMAP_ONE_PERSON.md
│   ├── JSON_CONTRACTS.md
│   ├── GITHUB_SETUP.md
│   ├── CODEX_APPLY_STARTER_PROMPT.md
│   └── schemas/
│       ├── room_state.schema.json
│       ├── asset_sidecar.schema.json
│       └── project_manifest.schema.json
├── engine/
│   ├── README.md
│   ├── data/
│   │   ├── dummy_level.json
│   │   └── assets/
│   │       ├── heroes/hero_knight/hero_knight.json
│   │       └── terrain/stone_floor/stone_floor.json
│   └── scripts/
│       ├── Main.gd
│       ├── PlayerController.gd
│       └── SmartEnemy.gd
├── editor/
│   ├── README.md
│   ├── src/
│   │   ├── App.svelte
│   │   ├── ToyboxModal.svelte
│   │   └── lib/canvasState.ts
│   └── src-tauri/
│       ├── Cargo.toml.additions
│       └── src/
│           ├── commands.rs
│           └── lib.rs
└── .github/workflows/ci.yml
```

## First real build step

1. Clone the repo.
2. Scaffold the Tauri/Svelte app into `editor/`.
3. Copy these starter files into the repo.
4. Create a Godot 4 project in `engine/`.
5. Add a `Node2D` named `Main` and attach `engine/scripts/Main.gd`.
6. Run `dummy_level.json` through the runner.
7. Only after the dummy room spawns, start the Rust ingestion daemon.

## Hard truth

This is not a small app. The MVP should **not** try to solve automatic AI tagging, automatic sprite animation grouping, full Metroidvania logic, weather, NPC routines, lighting, audio, save states, publishing, and child UX all at once.

The correct one-person path is:

1. JSON runner works.
2. Child can stamp objects and hit Play.
3. Rust can write `game_state.json`.
4. Sidecar assets can populate the toybox.
5. Deterministic sprite slicing works for transparent PNG sheets.
6. AI classification becomes an enhancement, not the foundation.

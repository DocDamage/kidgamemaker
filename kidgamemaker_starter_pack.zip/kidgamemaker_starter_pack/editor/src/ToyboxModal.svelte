<script lang="ts">
  import { createEventDispatcher, onMount } from "svelte";
  import { invoke } from "@tauri-apps/api/core";
  import { fade, fly } from "svelte/transition";
  import type { ToyboxAsset } from "./lib/canvasState";

  export let isVisible = false;

  const dispatch = createEventDispatcher<{
    itemSelected: ToyboxAsset;
    close: void;
  }>();

  let inventory: Record<string, ToyboxAsset[]> = {};
  let activeCategory = "terrain";
  let error = "";

  onMount(async () => {
    try {
      inventory = await invoke<Record<string, ToyboxAsset[]>>("get_asset_inventory");
      activeCategory = Object.keys(inventory)[0] ?? "terrain";
    } catch (err) {
      error = String(err);
      inventory = {
        heroes: [{ id: "hero_knight", name: "Hero Knight", category: "heroes", visual: "🛡️", type: "player" }],
        terrain: [{ id: "stone_floor", name: "Stone Floor", category: "terrain", visual: "🪨", type: "terrain" }]
      };
    }
  });

  function choose(item: ToyboxAsset) {
    dispatch("itemSelected", item);
  }
</script>

{#if isVisible}
  <div class="backdrop" transition:fade on:click={() => dispatch("close")}>
    <section class="modal" transition:fly={{ y: 180, duration: 180 }} on:click|stopPropagation>
      <header>
        <h2>Toybox</h2>
        <button on:click={() => dispatch("close")}>✕</button>
      </header>

      {#if error}
        <p class="error">Using fallback toybox. Rust inventory failed: {error}</p>
      {/if}

      <nav>
        {#each Object.keys(inventory) as category}
          <button class:active={activeCategory === category} on:click={() => (activeCategory = category)}>
            {category}
          </button>
        {/each}
      </nav>

      <div class="shelf">
        {#each inventory[activeCategory] ?? [] as item}
          <button class="asset" on:click={() => choose(item)}>
            <span>{item.visual ?? "🎮"}</span>
            <strong>{item.name}</strong>
          </button>
        {/each}
      </div>
    </section>
  </div>
{/if}

<style>
  .backdrop {
    position: fixed;
    inset: 0;
    display: grid;
    place-items: end center;
    background: rgba(0, 0, 0, 0.45);
    z-index: 50;
  }

  .modal {
    width: min(980px, calc(100vw - 32px));
    max-height: 78vh;
    overflow: auto;
    background: #f7efe2;
    color: #1e2430;
    border-radius: 32px 32px 0 0;
    padding: 22px;
    box-shadow: 0 -14px 40px rgba(0, 0, 0, 0.4);
  }

  header,
  nav,
  .shelf {
    display: flex;
    gap: 12px;
    align-items: center;
  }

  header {
    justify-content: space-between;
  }

  nav {
    flex-wrap: wrap;
    margin: 16px 0;
  }

  button {
    border: 0;
    border-radius: 18px;
    padding: 12px 18px;
    font-weight: 900;
    cursor: pointer;
    background: white;
    color: #1e2430;
  }

  button.active {
    outline: 4px solid #ffce3a;
  }

  .shelf {
    align-items: stretch;
    flex-wrap: wrap;
  }

  .asset {
    width: 140px;
    min-height: 120px;
    display: grid;
    place-items: center;
    gap: 6px;
    background: #ffffff;
  }

  .asset span {
    font-size: 2.5rem;
  }

  .error {
    color: #842020;
    font-weight: 700;
  }
</style>

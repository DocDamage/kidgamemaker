extends CharacterBody2D

@export var movement_speed: float = 80.0
@export var gravity_scale: float = 1.0

var gravity: float = ProjectSettings.get_setting("physics/2d/default_gravity")
var direction: float = -1.0


func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y += gravity * gravity_scale * delta

	velocity.x = direction * movement_speed
	move_and_slide()

	if is_on_wall():
		direction *= -1.0
